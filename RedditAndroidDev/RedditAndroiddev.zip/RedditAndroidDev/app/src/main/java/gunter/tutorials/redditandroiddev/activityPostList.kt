package gunter.tutorials.redditandroiddev

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import gunter.tutorials.redditandroiddev.Model.Children.Children
import kotlinx.android.synthetic.main.activity_post_list.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class activityPostList : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_post_list)

        requestWindowFeature(Window.FEATURE_NO_TITLE);   //will hide the title
        getSupportActionBar()!!.hide();                  //hide the title bar
        this.getWindow()!!.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_post_list)

        var titleList:ArrayList<Item> = ArrayList()
        // Inicializa requisição da API e exibe lista de títulos
        var titles = apiConnect()
        titleList = updateItemList(titles)

        val rv = recycleView
        rv.adapter = redditTitlesAdapter(titleList, this)

    }

    private fun updateItemList(titles: ArrayList<String>):ArrayList<Item> {
        var titleList:ArrayList<Item> = ArrayList()

        for((index, item) in titles.withIndex()) {
            var novoItem = Item(item)
            titleList.add(novoItem)
        }

        return titleList
    }

    private fun apiConnect(): ArrayList<String> {
        val apiInterface = ApiInterface.create().getFeed()
        var titleContent: ArrayList<String> = ArrayList()

        apiInterface.enqueue( object : Callback<Feed> {
            override fun onResponse(call: Call<Feed>?, response: Response<Feed>?) {
                if(response?.body() != null) {

                    val body = response?.body()?.data?.children

                    for ((index, item) in body!!.withIndex()) {
                        //title = body.get(index).data.title
                        titleContent.add(body?.get(index).data.title)
                    }

                    Toast.makeText(applicationContext, title.toString(), Toast.LENGTH_SHORT).show()
                }
                else {
                    Toast.makeText(applicationContext, "it's null ?", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Feed>?, t: Throwable?) {
                t?.printStackTrace()
                Toast.makeText(applicationContext, "it's failure  :(", Toast.LENGTH_SHORT).show()
            }
        })
        return titleContent
    }

}


// MANUAL VERSIONING:
//
// - added internet permission on manifest xml
// - added kotlinx coroutines on build.gradle