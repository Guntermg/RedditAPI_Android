package gunter.tutorials.redditandroiddev

class Item internal constructor(var title: String)